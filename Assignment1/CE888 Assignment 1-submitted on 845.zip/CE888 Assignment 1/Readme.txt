The PDF file called repot is the main file which contains the report and the plan at the end.

because the plan was really small and it was hard to read on PDF version, I added the Excel file too.

There is two notebook files. the first one (Assignment1_XO.ipynb) is the notebook I used to modify on colab.
The next one is the one I run on jupyter to get the output. It's the same as the above file but it has different outputs so I enclosed it.

The other 2 CSV files are my data set extracted after 150 times playing.

The link to my github : 
https://github.com/ParastooAzizinezhad/CE888-Labs
